# How Long Since Then
## Introduction
My Electron-based app to calculate how long since a past time to now. The main purpose is to learn how to use Electron writing multi-flatform app.

I never use JavaScript, HTML and CSS before so my code may be really bad. Besides that, i write this code just to relax in my free time so it may be a little dirty and there's bug here and there. Hope you can help me improve it.

Sorry for my bad English.

## Usage
Set your time in the past, then click the button.

## TODO
* Improve user interface.
* Add random quotes/facts about time.